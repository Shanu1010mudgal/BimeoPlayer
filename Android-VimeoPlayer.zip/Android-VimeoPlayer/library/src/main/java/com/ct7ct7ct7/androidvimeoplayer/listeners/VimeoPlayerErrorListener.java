package com.ct7ct7ct7.androidvimeoplayer.listeners;

public interface VimeoPlayerErrorListener {
    void onError(String message, String method, String name);
}
